export class Course {
    name: string;
    module: string;
    description: string;
 }