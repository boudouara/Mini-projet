export class Course {
}
